document.addEventListener('DOMContentLoaded', function() {
    const prestationsTable = document.getElementById('prestationsTable').getElementsByTagName('tbody')[0];
    const addPrestationBtn = document.getElementById('addPrestation');
    const totalGeneral = document.getElementById('totalGeneral');
    const devisForm = document.getElementById('devisForm');
    const mainOeuvreMontantInput = document.getElementById('mainOeuvreMontant');
    const totalMainOeuvre = document.getElementById('totalMainOeuvre');
    const successMsg = document.getElementById('successMsg');
    const devisApercu = document.getElementById('devisApercu');

    function getPrestations() {
        const prestations = [];
        prestationsTable.querySelectorAll('tr').forEach(row => {
            const desc = row.querySelector('.desc').value;
            const qty = row.querySelector('.qty').value;
            const price = row.querySelector('.price').value;
            const rowTotal = row.querySelector('.rowTotal').textContent;
            if(desc) prestations.push({desc, qty, price, rowTotal});
        });
        return prestations;
    }

    function updateApercu() {
        const prestations = getPrestations();
        const etablissementNom = document.getElementById('etablissementNom').value;
        const artisanNumero = document.getElementById('artisanNumero').value;
        const artisanNom = document.getElementById('artisanNom').value;
        const metier = document.getElementById('metier').value;
        const clientNom = document.getElementById('clientNom').value;
        const clientAdresse = document.getElementById('clientAdresse').value;
        const mainOeuvreTotal = parseFloat(mainOeuvreMontantInput.value) || 0;
        const total = parseFloat(totalGeneral.textContent) || 0;
        devisApercu.innerHTML = `
            <div class="apercu-header">
                <span class="apercu-logo">
                    <svg class="icon" viewBox="0 0 48 48"><circle cx="24" cy="24" r="22" fill="#fff" stroke="#10b981" stroke-width="4"/><path d="M14 32l8-8 8 8" stroke="#2563eb" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/><rect x="18" y="16" width="12" height="6" rx="2" fill="#2563eb"/></svg>
                </span>
                <span class="apercu-title">DEVIS</span>
            </div>
            <div class="apercu-info">
                <div><strong>Établissement :</strong> ${etablissementNom}</div>
                <div><strong>Numéro artisan :</strong> ${artisanNumero}</div>
                <div><strong>Artisan :</strong> ${artisanNom} (${metier})</div>
                <div><strong>Client :</strong> ${clientNom}</div>
                <div><strong>Adresse :</strong> ${clientAdresse}</div>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Description</th>
                        <th>Quantité</th>
                        <th>PU (FCFA)</th>
                        <th>Total (FCFA)</th>
                    </tr>
                </thead>
                <tbody>
                    ${prestations.length === 0 ? `<tr><td colspan='4' style='text-align:center;color:#aaa;'>Aucune prestation ajoutée</td></tr>` : prestations.map(p => `
                        <tr>
                            <td>${p.desc}</td>
                            <td>${p.qty}</td>
                            <td>${p.price}</td>
                            <td>${p.rowTotal}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
            <div class="apercu-totaux">Main d'œuvre : ${mainOeuvreTotal.toFixed(2)} FCFA</div>
            <div class="apercu-totaux">Total général : ${total.toFixed(2)} FCFA</div>
            <div class="apercu-footer">Merci pour votre confiance.</div>
        `;
    }

    function updateTotal() {
        let total = 0;
        prestationsTable.querySelectorAll('tr').forEach(row => {
            const qty = parseFloat(row.querySelector('.qty').value) || 0;
            const price = parseFloat(row.querySelector('.price').value) || 0;
            const rowTotal = qty * price;
            row.querySelector('.rowTotal').textContent = rowTotal.toFixed(2);
            total += rowTotal;
        });
        // Montant main d'oeuvre direct
        const mainOeuvreTotal = parseFloat(mainOeuvreMontantInput.value) || 0;
        totalMainOeuvre.textContent = mainOeuvreTotal.toFixed(2);
        total += mainOeuvreTotal;
        totalGeneral.textContent = total.toFixed(2);
        updateApercu();
    }

    function addPrestationRow() {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><input type="text" class="desc" placeholder="Description" required></td>
            <td><input type="number" class="qty" min="1" value="1" required></td>
            <td><input type="number" class="price" min="0" step="0.01" value="0.00" required></td>
            <td><span class="rowTotal">0.00</span></td>
            <td><button type="button" class="removeBtn"><i class="fa fa-trash"></i></button></td>
        `;
        row.classList.add('added');
        prestationsTable.appendChild(row);
        setTimeout(() => row.classList.remove('added'), 600);
        row.querySelectorAll('input').forEach(input => {
            input.addEventListener('input', updateTotal);
        });
        row.querySelector('.removeBtn').addEventListener('click', function() {
            row.classList.add('removed');
            setTimeout(() => {
                row.remove();
                updateTotal();
                updateApercu();
            }, 400);
        });
        updateTotal();
        updateApercu();
    }

    addPrestationBtn.addEventListener('click', addPrestationRow);
    // Ajoute une première ligne par défaut
    addPrestationRow();

    mainOeuvreMontantInput.addEventListener('input', updateTotal);
    devisForm.querySelectorAll('input').forEach(input => {
        input.addEventListener('input', updateTotal);
        input.addEventListener('input', updateApercu);
    });

    devisForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const prestations = getPrestations();
        if (prestations.length === 0) {
            alert('Veuillez ajouter au moins une prestation avant de générer le devis.');
            return;
        }
        const artisanNom = document.getElementById('artisanNom').value;
        const metier = document.getElementById('metier').value;
        const clientNom = document.getElementById('clientNom').value;
        const clientAdresse = document.getElementById('clientAdresse').value;
        const mainOeuvreTotal = parseFloat(mainOeuvreMontantInput.value) || 0;
        const total = parseFloat(totalGeneral.textContent) || 0;
        const btns = devisForm.querySelectorAll('button, #successMsg');
        btns.forEach(b => b.style.display = 'none');
        // Génération PDF avec jsPDF
        const doc = new window.jspdf.jsPDF({unit: 'pt', format: 'a4'});
        const pageWidth = doc.internal.pageSize.getWidth();
        let y = 40;
        // En-tête coloré avec logo SVG et titre
        doc.setFillColor(37, 99, 235);
        doc.rect(0, 0, pageWidth, 90, 'F');
        // Logo SVG simplifié (cercle + check)
        doc.setDrawColor(16, 185, 129);
        doc.setLineWidth(1.2);
        doc.circle(pageWidth-50, 45, 18, 'S');
        doc.setDrawColor(255,255,255);
        doc.setLineWidth(3);
        doc.line(pageWidth-60, 45, pageWidth-50, 60);
        doc.line(pageWidth-50, 60, pageWidth-38, 30);
        doc.setFont('helvetica','bold');
        doc.setFontSize(28);
        doc.setTextColor(255,255,255);
        doc.text('DEVIS', 40, 48);
        doc.setFont('helvetica','normal');
        doc.setFontSize(13);
        doc.setTextColor(224,247,250);
        const etablissementNom = document.getElementById('etablissementNom').value;
        const artisanNumero = document.getElementById('artisanNumero').value;
        doc.text(`Établissement : ${etablissementNom}`, 40, 68);
        doc.text(`Numéro artisan : ${artisanNumero}`, 40, 86);
        doc.setFont('helvetica','bold');
        doc.setFontSize(16);
        doc.setTextColor(255,255,255);
        doc.text(`Artisan : ${artisanNom} (${metier})`, 40, 106);
        y = 120;
        // Bloc client encadré
        doc.setDrawColor(16,185,129);
        doc.setFillColor(224, 247, 250);
        doc.roundedRect(40, y, pageWidth-80, 50, 8, 8, 'FD');
        doc.setFont('helvetica','normal');
        doc.setFontSize(13);
        doc.setTextColor(37,99,235);
        doc.text(`Client : ${clientNom}`, 55, y+22);
        doc.text(`Adresse : ${clientAdresse}`, 55, y+42);
        y += 70;
        // Tableau des prestations
        doc.setFont('helvetica','bold');
        doc.setFontSize(14);
        doc.setFillColor(224, 231, 255);
        doc.setTextColor(37,99,235);
        doc.rect(40, y, pageWidth-80, 28, 'F');
        doc.text('Description', 50, y+18);
        doc.text('Qté', 260, y+18);
        doc.text('PU (FCFA)', 320, y+18);
        doc.text('Total (FCFA)', 430, y+18);
        y += 32;
        doc.setFont('helvetica','normal');
        doc.setFontSize(12);
        let isOdd = false;
        prestations.forEach((p, i) => {
            if (y > 700) { // saut de page
                doc.addPage();
                y = 40;
            }
            if(isOdd) {
                doc.setFillColor(240, 253, 244);
                doc.rect(40, y, pageWidth-80, 24, 'F');
            }
            doc.setTextColor(34,34,34);
            doc.text(p.desc, 50, y+16);
            doc.text(String(p.qty), 260, y+16);
            doc.text(String(p.price), 320, y+16);
            doc.text(String(p.rowTotal), 430, y+16);
            y += 24;
            isOdd = !isOdd;
        });
        // Bloc totaux
        y += 10;
        doc.setFont('helvetica','bold');
        doc.setFontSize(13);
        doc.setTextColor(16,185,129);
        doc.text(`Main d'œuvre : ${mainOeuvreTotal.toFixed(2)} FCFA`, 320, y);
        y += 22;
        doc.setFontSize(16);
        doc.setTextColor(37,99,235);
        doc.text(`Total général : ${total.toFixed(2)} FCFA`, 320, y);
        // Footer
        y += 40;
        doc.setDrawColor(180,180,180);
        doc.setLineWidth(0.8);
        doc.line(320, y, 520, y); // trait pour la signature
        doc.setFont('helvetica','italic');
        doc.setFontSize(12);
        doc.setTextColor(100,116,139);
        doc.text("Signature de l'artisan", 320, y + 18);
        doc.setFont('helvetica','normal');
        doc.setFontSize(11);
        doc.setTextColor(100,116,139);
        doc.text('Merci pour votre confiance.', 40, 800);
        doc.text('Contact : danielvodjogbe@email.com', 320, 800);
        doc.save(`devis_${clientNom.replace(/\s+/g, '_')}.pdf`);
        btns.forEach(b => b.style.display = '');
        if(successMsg) {
            successMsg.style.display = 'block';
            setTimeout(()=>{ successMsg.style.display = 'none'; }, 3500);
        }
    });

    // Initialiser l'aperçu au chargement
    updateApercu();
}); 